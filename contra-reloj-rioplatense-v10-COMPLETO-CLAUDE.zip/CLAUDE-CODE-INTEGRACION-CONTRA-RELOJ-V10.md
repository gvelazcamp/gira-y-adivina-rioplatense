# IMPORTANTE — ESTE ES EL DOCUMENTO PRINCIPAL PARA CLAUDE CODE

Usar este archivo como especificación funcional y técnica para integrar
**Contra Reloj Rioplatense** dentro de:

`gvelazcamp/gira-y-adivina-rioplatense`

El HTML V10 incluido en el ZIP es un **prototipo funcional de referencia**.
No copiarlo entero dentro de `index.html`.

La integración final debe respetar la arquitectura existente del repositorio
y separar la nueva extensión en módulos.

## Reglas definitivas que NO deben cambiar

- Online: mínimo 4 personas.
- Mínimo 2 jugadores por grupo.
- Puede haber 2 o 3 grupos.
- Con 3 grupos: mínimo 6 personas.
- Cada tarjeta tiene 5 palabras/respuestas.
- Una sola cuenta regresiva de 30 segundos para las 5 palabras.
- El dado se tira **ANTES** de empezar la ronda.
- Dado: 0, 1 o 2.
- Todos conocen el descuento antes de ver/jugar la tarjeta.
- Puntaje: `max(0, acertadas - dado)`.
- Si el descriptor dice una respuesta, se anula solamente esa respuesta.
- La ronda continúa.
- En online:
  - descriptor ve la tarjeta;
  - compañeros del descriptor NO ven la tarjeta;
  - rivales SÍ ven la tarjeta para controlar.
- La voz online debe funcionar entre personas en casas/redes diferentes.
- MQTT NO transporta audio.
- WebRTC transporta audio.
- TURN debe quedar contemplado para producción.
- El árbitro automático solo analiza el micrófono LOCAL del descriptor.
- La respuesta hablada por un compañero NO puede provocar una anulación.
- El juego debe seguir funcionando aunque SpeechRecognition no esté disponible.
- No romper Duelo, Sala TV, compras, Supabase, mapa ni extensiones existentes.

---

# Contra Reloj Rioplatense — V10
## Integración completa para Claude Code
## Documento de integración para Claude Code

Este documento describe cómo integrar **Contra Reloj Rioplatense** dentro del repositorio existente de **Girá y Adiviná Rioplatense**.

Repositorio actual:

`gvelazcamp/gira-y-adivina-rioplatense`

La V8 de prototipo agrega:

- salas por código;
- 2 o 3 grupos;
- mínimo 2 personas por grupo;
- mínimo absoluto 4 jugadores;
- dado 0 / 1 / 2 antes de cada ronda;
- 5 palabras por tarjeta;
- 30 segundos;
- árbitro de voz en vivo;
- grabación local para reclamos;
- **audio en vivo entre jugadores mediante WebRTC**;
- **señalización WebRTC mediante MQTT**;
- soporte STUN;
- punto de integración preparado para TURN.

---

# 1. Regla definitiva del juego

Cada tarjeta contiene 5 respuestas distintas.

Ejemplo:

- PARÍS
- MATE
- DEADPOOL
- ROJO
- CARNAVAL

El descriptor tiene que lograr que su equipo adivine la mayor cantidad posible.

No puede pronunciar literalmente ninguna de las respuestas de la tarjeta.

Si pronuncia una respuesta:

- esa respuesta queda ANULADA;
- no se termina la ronda;
- continúa con las restantes.

---

# 2. Dado: se tira ANTES

El dado se tira antes de mostrar la tarjeta.

Flujo:

1. definir grupo;
2. definir descriptor;
3. tirar dado;
4. resultado 0, 1 o 2;
5. todos ven cuánto se descontará;
6. mostrar tarjeta;
7. 3 segundos para mirar;
8. 30 segundos de juego;
9. contar acertadas;
10. aplicar el descuento que ya había salido.

Fórmula:

`max(0, acertadas - dado)`

Ejemplo:

- dado = 2;
- acertadas = 5;
- suma = 3.

No se vuelve a tirar el dado al final.

---

# 3. Requisito de jugadores

Online requiere mínimo 4 personas.

## Con 2 grupos

- Grupo 1: mínimo 2.
- Grupo 2: mínimo 2.

Total mínimo: 4.

## Con 3 grupos

- Grupo 1: mínimo 2.
- Grupo 2: mínimo 2.
- Grupo 3: mínimo 2.

Total mínimo: 6.

El anfitrión no puede empezar si algún grupo está incompleto.

---

# 4. Roles de pantalla

## Descriptor

Ve:

- las 5 respuestas;
- dado de la ronda;
- tiempo;
- estado de cada respuesta;
- micrófono;
- árbitro automático.

Cuando su equipo adivina una respuesta, toca esa palabra.

## Compañeros del descriptor

NO ven la tarjeta.

Ven:

- grupo;
- reloj;
- dado;
- cantidad acertada;
- aviso de que deben escuchar y adivinar.

Escuchan al descriptor por WebRTC.

## Equipos rivales

Ven:

- las 5 respuestas;
- cuáles fueron acertadas;
- cuáles fueron anuladas;
- dado;
- tiempo.

Escuchan al descriptor.

Pueden marcar una respuesta como dicha si el árbitro automático no la detecta.

---

# 5. Voz online

## Objetivo

Permitir que personas en casas y redes diferentes jueguen sin WhatsApp, Discord ni Meet.

Flujo esperado:

`ENTRAR CON CÓDIGO → ELEGIR GRUPO → ACTIVAR MICRÓFONO → TODOS LISTOS → EMPEZAR`

## Tecnología

### MQTT

Usar para:

- código de sala;
- ingreso/salida de jugadores;
- equipo elegido;
- turno;
- tarjeta privada;
- estado;
- reloj autoritativo;
- aciertos;
- anulaciones;
- dado;
- puntaje;
- señalización WebRTC.

NO usar MQTT para enviar audio.

### WebRTC

Usar para:

- audio de los jugadores.

Cada navegador mantiene conexiones `RTCPeerConnection`.

Para 4–6 personas y audio solamente, una topología mesh es razonable como primera versión.

---

# 6. Señalización WebRTC por MQTT

El prototipo usa:

`gyacontrareloj/v1/{CODIGO}/rtc/{PID}`

y:

`gyacontrareloj/v1/{CODIGO}/rtc/all`

Tipos de mensaje:

- `voice_hello`
- `voice_bye`
- `offer`
- `answer`
- `ice`

Ejemplo conceptual:

```json
{
  "from": "p123",
  "to": "p456",
  "type": "offer",
  "sdp": {}
}
```

El audio nunca se incluye en estos mensajes.

---

# 7. STUN y TURN

La V8 incluye STUN:

```js
[
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" }
]
```

Esto permite probar WebRTC y funcionará en muchas redes.

## TURN es necesario para producción

Para que el juego sea confiable con:

- Wi‑Fi doméstico;
- CGNAT;
- datos móviles;
- redes empresariales;
- routers restrictivos;

hay que tener TURN.

No poner usuario/contraseña TURN permanentes dentro de JavaScript público.

### Implementación recomendada

Crear un endpoint que entregue credenciales temporales.

Opciones posibles:

- Supabase Edge Function;
- Cloudflare Worker;
- backend propio;
- proveedor TURN administrado con credenciales efímeras.

El cliente debería terminar recibiendo algo similar a:

```json
{
  "iceServers": [
    {
      "urls": "turn:turn.example.com:3478",
      "username": "TEMP_USER",
      "credential": "TEMP_PASSWORD"
    }
  ]
}
```

Luego agregarlo a la configuración de `RTCPeerConnection`.

En el prototipo se admite:

```js
window.GYA_TURN_SERVERS = [...]
```

pero esto es solo un punto de integración.

---

# 8. Permisos de micrófono

El navegador debe pedir:

```js
navigator.mediaDevices.getUserMedia({ audio: true })
```

Usar:

```js
audio: {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true
}
```

Cada jugador debe tocar explícitamente `ACTIVAR MICRÓFONO`.

El anfitrión no puede iniciar la partida hasta que todos figuren:

`🎙 listo`

Esto también evita que una partida arranque con alguien que no puede escuchar/hablar.

---

# 9. TWA / Android

El proyecto actual es PWA y se empaqueta como TWA.

Claude Code debe revisar la parte Android/PWABuilder antes de publicar el micrófono en producción.

Validar:

- permiso de grabación de audio del paquete Android;
- comportamiento de `getUserMedia()` dentro de la TWA;
- que el origen HTTPS de GitHub Pages esté correctamente asociado;
- flujo de permiso Android + permiso web;
- comportamiento después de negar permiso;
- reentrada a una sala después de volver desde configuración.

No modificar permisos a ciegas: comprobar primero la estructura Android existente generada por PWABuilder.

---

# 10. Árbitro automático

El árbitro NO analiza el audio remoto.

Analiza exclusivamente el micrófono LOCAL del descriptor.

Esto es importante.

Ejemplo:

Gonzalo describe.

Martín responde:

> “¿Rojo?”

El sistema no debe anular ROJO porque Martín lo dijo.

Solamente debe anularlo si el micrófono/transcripción local de Gonzalo detecta que Gonzalo pronunció ROJO.

El prototipo usa:

- `SpeechRecognition`, o;
- `webkitSpeechRecognition`.

Si el navegador no soporta reconocimiento:

- la voz WebRTC debe seguir funcionando;
- los rivales siguen teniendo control manual;
- no bloquear la partida.

---

# 11. Audio para reclamos

`MediaRecorder` puede guardar localmente la voz del descriptor durante la ronda.

Regla:

- no reproducir/revisar audio después de cada ronda;
- usarlo únicamente si existe una discusión;
- no subirlo automáticamente;
- destruirlo al avanzar/cerrar si no se necesita.

Para una futura revisión remota desde otro teléfono habría que subir temporalmente el clip a storage.

Eso NO es obligatorio para la primera versión.

---

# 12. Arquitectura sugerida en el repositorio

No meter toda esta lógica dentro de `index.html`.

Crear archivos separados.

Sugerencia:

```text
contra-reloj-rioplatense.js
contra-reloj-rioplatense-datos.js
contra-reloj-rioplatense-online.js
contra-reloj-rioplatense-voz.js
logo-contra-reloj-rioplatense.svg
```

## `contra-reloj-rioplatense-datos.js`

Solo tarjetas.

Ejemplo:

```js
window.CONTRA_RELOJ_TARJETAS = [
  ["PARÍS","MATE","DEADPOOL","ROJO","CARNAVAL"]
];
```

## `contra-reloj-rioplatense.js`

Responsable de:

- UI;
- modo normal;
- modo árbitro;
- reloj;
- dado;
- tarjetas;
- aciertos;
- resultado;
- persistencia de récord si corresponde.

Exponer:

```js
window.ContraRelojRioplatense = {
  abrir(contenedor),
  salir(),
  mejorPuntaje()
};
```

## `contra-reloj-rioplatense-online.js`

Responsable de:

- salas;
- equipos;
- host;
- estado autoritativo;
- turnos;
- tarjetas privadas;
- dado sincronizado;
- puntaje;
- mensajes MQTT.

No enviar la tarjeta completa al canal público.

## `contra-reloj-rioplatense-voz.js`

Responsable de:

- `getUserMedia`;
- WebRTC;
- STUN/TURN;
- peers;
- offer;
- answer;
- ICE;
- mute;
- audio remoto;
- reconexión;
- cierre limpio.

No mezclar estado del juego con estado del audio.

---

# 13. Reutilizar lo que ya existe

El repositorio ya tiene:

- MQTT cargado desde `index.html`;
- función/concepto de conexión usado por salas;
- `duelo-extensiones.js`;
- `sala-tv.js`;
- catálogo `EXTENSIONES`;
- estilos `extensiones.css`.

No duplicar la librería MQTT.

No crear otra implementación global que rompa `Duelo`.

Contra Reloj debe usar su propio namespace/canal MQTT.

---

# 14. Integración en `EXTENSIONES`

Agregar una entrada equivalente a:

```js
{
  id: "contra-reloj-rioplatense",
  nombre: "Contra Reloj",
  descripcion: "Describí 5 palabras antes de que termine el tiempo",
  icono: "logo-contra-reloj-rioplatense.svg",
  estado: "disponible",
  abrir: contenedor => ContraRelojRioplatense.abrir(contenedor),
  record: () => ContraRelojRioplatense.mejorPuntaje() + " puntos"
}
```

También agregar `window.ContraRelojRioplatense` al cierre general de extensiones.

---

# 15. Diseño del icono

Debe seguir el formato de los logos actuales de extensiones:

- icono cuadrado;
- fondo transparente o preparado para tarjeta;
- cronómetro;
- cuatro personas;
- badge `4+`;
- sin texto largo dentro del icono.

La tarjeta de extensión debe mostrar aparte:

`Contra Reloj`

y la descripción:

`Describí 5 palabras antes de que termine el tiempo`

Añadir visualmente:

`4+ jugadores`

---

# 16. Persistencia

Usar prefijo `gya_`.

Ejemplo:

- `gya_contra_reloj_record`
- `gya_contra_reloj_partidas`
- `gya_contra_reloj_aciertos`

No guardar audio en `localStorage`.

---

# 17. Seguridad / validaciones

El HOST debe ser autoritativo para:

- iniciar partida;
- elegir turno;
- reloj;
- dado;
- terminar ronda;
- puntaje final.

Validar mensajes MQTT.

Nunca confiar ciegamente en un cliente remoto para sumar puntos.

Limitar:

- nombres;
- PID;
- códigos;
- índices de palabra;
- estados válidos;
- tamaño de mensajes SDP/ICE razonable.

---

# 18. Reconexión

Necesario para Android/celular.

Si un jugador:

- bloquea pantalla;
- cambia de Wi‑Fi a datos;
- pierde señal;
- minimiza la app;

el sistema debe intentar:

1. reconectar MQTT;
2. volver a anunciar `voice_hello`;
3. destruir peers fallidos;
4. renegociar WebRTC;
5. recuperar snapshot de la sala;
6. mantener equipo y PID cuando sea seguro.

---

# 19. Audio y música del juego

Cuando se entra en la sala de voz:

- bajar/pausar música de fondo de la extensión;
- no permitir que la música tape a otros jugadores.

Los efectos cortos sí pueden mantenerse:

- dado;
- acierto;
- palabra anulada;
- fin de tiempo.

---

# 20. Pruebas mínimas antes de integrar

Probar como mínimo:

### Caso A
4 celulares en el mismo Wi‑Fi.

### Caso B
2 celulares en Wi‑Fi + 2 con datos móviles.

### Caso C
4 redes distintas.

### Caso D
un jugador niega micrófono.

### Caso E
un jugador se desconecta y vuelve.

### Caso F
descriptor cambia de Wi‑Fi a datos durante una ronda.

### Caso G
Android TWA instalada desde Play.

### Caso H
Chrome navegador normal.

### Caso I
un navegador sin `SpeechRecognition`.

La partida debe seguir funcionando aunque falle el árbitro automático.

---

# 21. Service Worker

Al agregar archivos nuevos:

- incluirlos en la estrategia/cache correspondiente;
- subir la versión del cache;
- no dejar una versión anterior pegada en producción.

Seguir la política ya usada en el proyecto:
- assets cache-first;
- HTML/JS network-first cuando corresponda.

---

# 22. No romper lo existente

Reglas para Claude Code:

1. Leer primero los archivos actuales completos relevantes.
2. Reutilizar `conectar()` / MQTT existente cuando sea adecuado.
3. No modificar Duelo 1vs1 salvo que sea estrictamente necesario.
4. Mantener Sala TV funcionando.
5. Mantener compras, Supabase, mapas y juego principal intactos.
6. Crear Contra Reloj como módulo aislado.
7. No cambiar nombres de claves existentes.
8. No borrar código funcional.
9. Hacer cambios pequeños e integrables.
10. Después de cada integración, probar consola sin errores.

---

# 23. Resultado final esperado

Cuatro personas en cuatro casas diferentes deben poder:

1. abrir Girá y Adiviná;
2. entrar a Extensiones;
3. abrir Contra Reloj;
4. uno crea sala;
5. recibe código;
6. los otros tres entran;
7. eligen Grupo 1 / Grupo 2;
8. cada grupo tiene mínimo 2;
9. todos activan micrófono;
10. el anfitrión inicia;
11. se prepara turno;
12. se tira dado;
13. todos ven el descuento;
14. empieza la ronda;
15. el descriptor habla;
16. todos lo escuchan;
17. su equipo adivina;
18. rivales controlan;
19. árbitro automático anula respuestas dichas;
20. termina el tiempo;
21. se aplica el dado;
22. cambia de grupo;
23. rota quién describe;
24. continúa la partida.

Ese es el objetivo de producción.


---

# V9 — Assets definitivos del dado

Usar estos tres PNG transparentes:

```text
dado-contra-reloj-0.png
dado-contra-reloj-1.png
dado-contra-reloj-2.png
```

Son el mismo dado dorado 3D con las caras frontales 0, 1 y 2.

No volver a dibujar el dado mediante CSS/SVG.

## Animación

Durante `TIRAR DADO`:

1. alternar rápidamente entre las imágenes 0, 1 y 2;
2. aplicar rotación;
3. elevar el dado;
4. hacerlo picar/rebotar dos o tres veces;
5. detenerse en el valor que ya determinó la lógica;
6. mantener visible ese mismo valor durante toda la ronda.

La animación es solamente visual. El resultado del dado lo sigue decidiendo la lógica del juego.


---

# V10 — Dado definitivo

Los assets definitivos incluidos en este ZIP son:

```text
dado-contra-reloj-0.png
dado-contra-reloj-1.png
dado-contra-reloj-2.png
```

Son PNG transparentes 3D dorados y deben usarse como assets normales del repo.

## Integración recomendada

Ubicarlos, por ejemplo, en:

```text
assets/extensiones/contra-reloj/dado-0.png
assets/extensiones/contra-reloj/dado-1.png
assets/extensiones/contra-reloj/dado-2.png
```

En producción NO hace falta incrustarlos como base64.

El HTML V10 los lleva incrustados únicamente para que el prototipo descargable
funcione como un único archivo.

## Animación del dado

Al tocar `TIRAR DADO`:

1. elegir el resultado lógico 0 / 1 / 2;
2. animar visualmente el dado;
3. alternar rápidamente entre los tres assets;
4. aplicar subida + giro + varios piques/rebotes;
5. terminar mostrando el asset correspondiente al resultado real;
6. mantener ese valor visible durante toda la ronda.

La animación no debe decidir el resultado.

El valor lógico debe determinarse una sola vez y mantenerse sincronizado por el HOST.

## Aleatoriedad actual

El prototipo usa:

```js
Math.floor(Math.random() * 3)
```

por lo que 0, 1 y 2 tienen aproximadamente la misma probabilidad.

---

# Qué debe hacer Claude Code al recibir este ZIP

1. Leer primero el repo actual.
2. Revisar `index.html`, `extensiones.js`, `extensiones.css`,
   `duelo-extensiones.js`, `sala-tv.js`, manifest/service worker y la parte Android/TWA.
3. No reemplazar sistemas existentes.
4. Crear Contra Reloj como extensión aislada.
5. Reutilizar el MQTT/conector existente donde corresponda.
6. Crear módulo WebRTC independiente.
7. Implementar señalización WebRTC sobre MQTT.
8. Implementar salas de 2 o 3 grupos.
9. Exigir mínimo 2 personas por grupo.
10. Implementar roles privados correctamente.
11. Implementar dado ANTES de la ronda.
12. Integrar los 3 PNG del dado.
13. Implementar árbitro de voz local al descriptor.
14. Implementar audio remoto WebRTC.
15. Preparar TURN con credenciales temporales, nunca secretos fijos en el repo.
16. Revisar permisos de micrófono de PWA/TWA/Android.
17. Implementar reconexión.
18. Mantener la partida operativa si falla SpeechRecognition.
19. Probar entre redes distintas.
20. Actualizar cache/service worker.
21. Dejar consola sin errores.
22. No subir cambios destructivos ni borrar código funcional existente.

