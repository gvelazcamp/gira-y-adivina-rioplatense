# Contra Reloj Rioplatense — V10

Corrección real del problema de los dados.

## Causa
Las versiones anteriores incrustaban los PNG en base64 y luego hacían un reemplazo global del texto de versión (`V9`).
Esa sustitución podía modificar caracteres dentro del propio base64 y corromper la imagen.

## V10
- Se parte de la V9 limpia.
- Se hacen primero todos los cambios de texto.
- Después se incrustan los tres PNG.
- Una vez incrustados, no se vuelve a modificar el HTML.
- Se verificó que cada base64 decodifica exactamente al PNG original.
- Se validó la sintaxis JavaScript.

Antes de tirar se muestra el dado dorado real con `?` superpuesto.
Al tirar, alterna 0/1/2 y termina en el resultado.
